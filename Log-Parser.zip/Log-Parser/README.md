# 🔍 Log Parser Tool

A simple command-line tool written in C for parsing and analyzing log files.  
It supports log level filtering, optional time-based sorting, and log statistics.

## 📦 Features

- Parse logs in the format: `[TIME] [LEVEL] MESSAGE`
- Filter logs by level; `INFO`, `WARNING`, `ERROR`
- Sort logs by time
- Display count summary for each log level

## 🖥️ Sample Log Format
[11:05] [INFO] System started
[09:15] [ERROR] Failed to open database
[10:45] [INFO] User login successful

## ▶️ Run
./log_parser -f <filename> [options]
    **📘 Options**
    - "-f <filename>": specify log file to be parsed (required)
    **📘 Options**
    - "-l <level>": filter logs by level
    - "-s": sort logs by time 
    **EXAMPLE**
        - ./log_parser -f sample.log
        - ./log_parser -f sample.log -l ERROR
        - ./log_parser -f sample.log -s
        - ./log_parser -f sample.log -l INFO -s

## 📊 Output Example
...
[11:15] [ERROR] Service timeout
[15:45] [ERROR] Deadlock detected
[13:00] [ERROR] Sync conflict

[INFO]: 56      [ERROR]: 21     [WARNING]: 23

## 🌲 File Structure
Log-Parser
├── include
│   └── parser.h
├── log_parser
├── Makefile
├── obj
│   ├── main.o
│   └── parser.o
├── README.md
├── sample.log
└── src
    ├── main.c
    └── parser.c

## Future Improvement
    - Make a function that outputs to file (-o <outputfile-name>)
    - JSON or CSV export
    - Program that generates random a sample log
    - Versatile functionality that extracts time, level, and message from a file written in a different format